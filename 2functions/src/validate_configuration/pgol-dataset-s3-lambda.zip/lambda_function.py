import json
import boto3
import base64

def lambda_handler(event, context):
    print(event)
    
    if "body" in event:
        if validate_configuration(event['body']):

            client = boto3.client('stepfunctions')
            response = client.start_execution(
                stateMachineArn='arn:aws:states:ap-southeast-2:317382776567:stateMachine:pgol-dataset-s3-stepfunction',
                input = event['body']
            )
            print("response from step func start_execution:")
            print(response)
            
            return {
                "statusCode": 200,
                "headers": {
                    "Content-Type": "application/json"
                },
                "body": json.dumps({
                    "received_body ": event['body'],
                    "message": "Request received and validated."
                })
            }
        else:
            print("validation failed, #TODO respond to the caller with error message ")
            print("body exists")
            body = event['body']
            print(body)
    else:
        print("body was not passing in request")
        return {
            "statusCode": 400,
            "headers": {
                "Content-Type": "application/json"
            },
            "body": json.dumps({
                "received_body ": '',
                "message": "Request must contain a request body with a valid configuration"
            })
        }


        
    #print(json.dumps(response))

    
def validate_configuration(configuration):
    #TODO validate the configuration
    return True
    